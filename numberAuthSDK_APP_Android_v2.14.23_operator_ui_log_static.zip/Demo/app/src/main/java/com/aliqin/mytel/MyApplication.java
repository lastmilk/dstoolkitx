package com.aliqin.mytel;

import android.app.Application;
import android.util.Log;

import com.mobile.auth.gatewayauth.PhoneNumberAuthHelper;
import com.mobile.auth.gatewayauth.TokenResultListener;
import com.aliqin.mytel.BuildConfig;
import com.mobile.auth.gatewayauth.manager.FeatureManager;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        //减少网络请求频次，调用要在创建sdk入口对象前
        //FeatureManager.getInstance().put(FeatureManager.FEATURE_KEY_REDUCE_NETWORKACCESS,"true");
        /*建议提前进行sdk初始化，减少流程耗时*/
        final PhoneNumberAuthHelper authHelper = PhoneNumberAuthHelper.getInstance(this, new TokenResultListener() {
            @Override
            public void onTokenSuccess(String ret) {
            }

            @Override
            public void onTokenFailed(String ret) {
            }
        });
        authHelper.getReporter().setLoggerEnable(true);
        authHelper.setAuthSDKInfo(BuildConfig.AUTH_SECRET);
    }

}
