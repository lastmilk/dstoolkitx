pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
    plugins {
        id("com.android.application") version "8.6.1" apply false
        id("org.jetbrains.kotlin.android") version "2.1.21" apply false
        id("org.jetbrains.kotlin.plugin.compose") version "2.1.21" apply false
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "gt-captcha-v4-android"

include(":app")
