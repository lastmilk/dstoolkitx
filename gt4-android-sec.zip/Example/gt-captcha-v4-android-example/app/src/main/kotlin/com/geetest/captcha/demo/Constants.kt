package com.geetest.captcha.demo

object Constants {
    const val TAG = "GTCaptcha4Demo"
}
