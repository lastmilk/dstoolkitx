package com.geetest.captcha.demo

import android.content.Context
import android.os.Looper
import android.util.Log
import com.geetest.captcha.GTCaptcha4Client
import com.geetest.captcha.GTCaptcha4Config
import com.geetest.captcha.demo.Constants.TAG

object GTCaptcha4Utils {
    const val CAPTCHA_ID = "22ea998073763d3c08dc5d80022b1a5d"

    fun newGTCaptcha4Client(context: Context): GTCaptcha4Client {
        val config = GTCaptcha4Config.Builder()
            .build()

        val client = GTCaptcha4Client.getClient(context)
        client.setLogEnable(true)
        client
            .init(CAPTCHA_ID, config)
            .addOnSuccessListener { status, response ->
                Log.e(TAG, "onSuccess: $response, ${Looper.getMainLooper() == Looper.myLooper()}")
                if (status) {
                    // TODO 开启二次验证
                    // TODO start secondary verification
                } else {
                    // TODO user answer verification error
                    // TODO 用户答案验证错误
                }
            }
            .addOnFailureListener { error ->
                Log.e(TAG, "onFailure: $error, ${Looper.getMainLooper() == Looper.myLooper()}")
                // TODO 处理错误
                // TODO Handle Error
            }
            .addOnWebViewShowListener {
                Log.e(TAG, "onWebViewShow ${Looper.getMainLooper() == Looper.myLooper()}")
            }
        return client
    }
}