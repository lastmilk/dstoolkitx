package com.geetest.captcha.demo

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.geetest.captcha.GTCaptcha4Client

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppWithNavigation() {
    var selectedScreen by remember { mutableStateOf(Screen.Home) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = selectedScreen.title,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
            )
        },
        bottomBar = {
            NavigationBar {
                Screen.entries.forEach { screen ->
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = {
                            Text(screen.title)
                        },
                        selected = selectedScreen == screen,
                        onClick = {
                            selectedScreen = screen
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val context = LocalContext.current
            when (selectedScreen) {
                Screen.Home -> HomeScreen({ _, _ ->
                    val captchaClient = GTCaptcha4Utils.newGTCaptcha4Client(context)
                    captchaClient.verifyWithCaptcha()
                })

                Screen.Preload -> {
                    var captchaClient: GTCaptcha4Client? = null

                    LaunchedEffect(Unit) {
                        captchaClient = GTCaptcha4Utils.newGTCaptcha4Client(context)
                    }

                    HomeScreen({ _, _ ->
                        captchaClient?.verifyWithCaptcha()
                    })
                }
            }
        }
    }
}

enum class Screen(
    val title: String,
    val icon: ImageVector,
) {
    Home("Home", Icons.Default.Home),
    Preload("Preload", Icons.Default.AccountCircle)
}
